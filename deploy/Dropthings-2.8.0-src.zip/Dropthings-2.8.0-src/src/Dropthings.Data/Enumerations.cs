﻿namespace Dropthings.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class Enumerations
    {
        #region Enumerations

        public enum PageType
        {
            PersonalTab = 0
        }

        public enum WidgetType
        {
            PersonalTab = 0
        }

        #endregion Enumerations
    }
}