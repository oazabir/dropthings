#region Header

// Copyright (c) Omar AL Zabir. All rights reserved.
// For continued development and updates, visit http://msmvps.com/omar

#endregion Header

namespace CustomDragDrop
{
    using System.Web.UI;
    using System.Web.UI.WebControls;

    class CustomDragDropDesigner : AjaxControlToolkit.Design.ExtenderControlBaseDesigner<CustomDragDropExtender>
    {
    }
}