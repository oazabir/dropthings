﻿namespace Dropthings.Business.Workflows
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Dropthings.DataAccess;

    public class SetupDefaultRolesWorkflowResponse : UserWorkflowResponseBase
    {
    }
}