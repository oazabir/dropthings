﻿namespace Dropthings.Business.Workflows.UserAccountWorkflow
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Dropthings.Business.Workflows.EntryPointWorkflows;
    using Dropthings.Business.Workflows.UserAccountWorkflows;
    using Dropthings.DataAccess;

    public class CreateTemplateUserWorkflowResponse : UserRegistrationWorkflowResponse
    {
    }
}