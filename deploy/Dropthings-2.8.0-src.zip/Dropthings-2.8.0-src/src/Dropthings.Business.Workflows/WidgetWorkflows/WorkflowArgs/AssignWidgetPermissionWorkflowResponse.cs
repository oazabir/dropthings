﻿namespace Dropthings.Business.Workflows.WidgetWorkflows.WorkflowArgs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Dropthings.DataAccess;

    public class AssignWidgetPermissionResponse : UserWorkflowResponseBase
    {
    }
}