﻿namespace Dropthings.Business.Workflows
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Dropthings.DataAccess;

    public class WidgetInstanceResponseBase
    {
        #region Properties

        public WidgetInstance WidgetInstanceAffected
        {
            get;
            set;
        }

        #endregion Properties
    }
}